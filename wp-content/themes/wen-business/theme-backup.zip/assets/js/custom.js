( function( $ ) {

  $(document).ready(function($){

    // Trigger mmenu
    $('#mob-menu').mmenu();

  });

} )( jQuery );
