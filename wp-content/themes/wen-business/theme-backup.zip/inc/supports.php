<?php


require_if_theme_supports( 'footer-widgets', get_template_directory() . '/inc/supports/footer-widgets.php' );
