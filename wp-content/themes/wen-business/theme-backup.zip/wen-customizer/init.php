<?php

/**
 * Include custom controls
 */
require_once 'controls.php';

/**
 * Include main customizer class
 */
require_once 'class-wen-customizer.php';
